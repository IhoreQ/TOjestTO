package pl.bobkins.polar;

public interface IPolar2D {
    double getAngle();
    double abs();
}
